
from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Models
class Entity(BaseModel):
    entity_type: str
    value: str

class Summary(BaseModel):
    content: str

class DocumentResponse(BaseModel):
    document_id: str
    text: str
    entities: List[Entity]
    summary: Summary

# Routes
@app.post("/upload")
async def upload_document(file: UploadFile = File(...)):
    return {"document_id": "doc123"}

@app.get("/document/{doc_id}", response_model=DocumentResponse)
async def get_document(doc_id: str):
    return DocumentResponse(
        document_id=doc_id,
        text="Sample extracted historical content...",
        entities=[Entity(entity_type="person", value="Queen Elizabeth")],
        summary=Summary(content="This document discusses the Elizabethan era...")
    )
