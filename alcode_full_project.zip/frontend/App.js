
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

function Dashboard() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Welcome to Alcode</h2>
      <Link to="/upload">
        <Button>Upload New Document</Button>
      </Link>
    </div>
  );
}

function UploadPage() {
  const [file, setFile] = useState(null);
  const [uploadedId, setUploadedId] = useState(null);

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append("file", file);
    const res = await axios.post("http://localhost:8000/upload", formData);
    setUploadedId(res.data.document_id);
  };

  return (
    <div className="p-6">
      <input type="file" onChange={e => setFile(e.target.files[0])} />
      <Button className="ml-2" onClick={handleUpload}>Upload</Button>
      {uploadedId && <p className="mt-4">Uploaded Document ID: {uploadedId}</p>}
    </div>
  );
}

function DocumentView({ id }) {
  const [doc, setDoc] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:8000/document/${id}`).then(res => setDoc(res.data));
  }, [id]);

  if (!doc) return <p>Loading...</p>;

  return (
    <div className="p-6">
      <h2 className="text-xl font-semibold mb-2">Document: {id}</h2>
      <Textarea rows={10} className="w-full mb-4" defaultValue={doc.text} />
      <div>
        <h3 className="font-semibold">Entities</h3>
        <ul className="list-disc ml-6">
          {doc.entities.map((e, i) => (
            <li key={i}>{e.entity_type}: {e.value}</li>
          ))}
        </ul>
      </div>
      <div className="mt-4">
        <h3 className="font-semibold">Summary</h3>
        <p>{doc.summary.content}</p>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <nav className="p-4 bg-white shadow-md flex justify-between">
        <Link to="/">Dashboard</Link>
        <Link to="/upload">Upload</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/upload" element={<UploadPage />} />
        <Route path="/document/:id" element={<DocumentView />} />
      </Routes>
    </Router>
  );
}
